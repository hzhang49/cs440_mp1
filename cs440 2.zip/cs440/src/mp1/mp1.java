package mp1;

import mp1.read_maze.info;

public class mp1 {
//	static int[][] m_maze = new int[23][23];	//medium maze
//	static int[][] b_maze = new int[37][37];	//big maze
//	static int[][] o_maze = new int[20][37];	//open maze
	
	public static void print_maze(int[][] maze){
		int row = maze.length;
		int col = maze[0].length;
		for(int i = 0; i < row; i++){
			String s = "";
			for(int j = 0; j < col; j++){
				if(maze[i][j] == 0 ){
					s += " ";
				}else if(maze[i][j] == 1){
					s+="%";
				}else if(maze[i][j] == 2){
					s+= "P";
				}else if(maze[i][j] == 3 || maze[i][j] == 4){
					s+= ".";
				}else if(maze[i][j] == 5){
					s+= "*";
				}
			}
			System.out.println(s);
		}
	}
	public static void main(String[] args){	
		/*read maze files*/
		read_maze r =  new read_maze();
		info m_info = r.in("mediumMaze.txt", 23, 23);
		info b_info = r.in("bigMaze.txt", 37, 37);
		info o_info = r.in("openMaze.txt",20, 37);
		info tiny_s = r.in("tinySearch.txt",8, 23);
		info small_s = r.in("smallSearch.txt",13, 30);
		info medium_s = r.in("mediumSearch.txt",13, 49);
		//print_maze(medium_s.maze);
		System.out.println();
		gready_best_first test = new gready_best_first();
		int [][] k = {{o_info.start_x, o_info.start_y},{o_info.d.get(0).x, o_info.d.get(0).y}};
		test.basic(o_info.maze, k);
		//test.multi_dot(b_info);
		
		print_maze(o_info.maze);
	}
}
